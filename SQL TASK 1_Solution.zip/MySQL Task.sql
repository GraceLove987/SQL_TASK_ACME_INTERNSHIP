SELECT * FROM smartphone.smartphone_cleaned_v2;

-- Data Retrieval
SELECT price, brand_name FROM smartphone.smartphone_cleaned_v2;
SELECT price, brand_name FROM smartphone.smartphone_cleaned_v2 WHERE has_5g = "True";

-- Data Manipulation 
  -- filtered by my affordable prices of phone
SELECT * FROM smartphone.smartphone_cleaned_v2 WHERE price <= 80000;
  -- Sort by brandname in ascending order
SELECT * FROM smartphone.smartphone_cleaned_v2 ORDER BY brand_name ASC;
  -- Aggregate unique brand name of my affordable prices of phone
SELECT COUNT(DISTINCT brand_name) AS total_brand_name FROM smartphone.smartphone_cleaned_v2 WHERE price <= 80000;
 
-- Data Analysis
  -- Count the unique number of brandname
SELECT COUNT(DISTINCT brand_name) AS total_brand_name FROM smartphone.smartphone_cleaned_v2;
  -- Calculate the average price 
SELECT AVG(price) AS average_price FROM smartphone.smartphone_cleaned_v2;
  -- Utilize GROUP BY and HAVING clauses
SELECT has_5g, COUNT(brand_name) AS brand_name_count FROM smartphone.smartphone_cleaned_v2 GROUP BY has_5g;
SELECT has_5g, COUNT(brand_name) AS brand_name_count FROM smartphone.smartphone_cleaned_v2 GROUP BY has_5g HAVING has_5g = "True";

  -- Conditional Logic
SELECT brand_name, price,
CASE
    WHEN price <= 80000 THEN 'That is my Choice of Phone'
    WHEN price BETWEEN 80000 AND 10000 THEN 'Considerably, I can still buy it'
    ELSE 'Too high'
END AS my_price_category FROM smartphone.smartphone_cleaned_v2;







